Type.registerNamespace('AjaxControlToolkit')
AjaxControlToolkit.BoxSide=function(){}
AjaxControlToolkit.BoxSide.prototype={
Top : 0,
Right : 1,
Bottom : 2,
Left : 3}
AjaxControlToolkit.BoxSide.registerEnum("AjaxControlToolkit.BoxSide",false)
AjaxControlToolkit._CommonToolkitScripts=function(){
this._borderThicknesses={}
var div0=document.createElement('div')
var div1=document.createElement('div')
div0.style.visibility='hidden'
div0.style.position='absolute'
div0.style.fontSize='1px'
div1.style.height='0px'
div1.style.overflow='hidden'
document.body.appendChild(div0).appendChild(div1)
var base=div0.offsetHeight
div1.style.borderTop='solid black'
div1.style.borderTopWidth='thin'
this._borderThicknesses['thin']=div0.offsetHeight-base
div1.style.borderTopWidth='medium'
this._borderThicknesses['medium']=div0.offsetHeight-base
div1.style.borderTopWidth='thick'
this._borderThicknesses['thick']=div0.offsetHeight-base
div0.removeChild(div1)
document.body.removeChild(div0)
div0=null
div1=null}
AjaxControlToolkit._CommonToolkitScripts.prototype={
_borderStyleNames : ['borderTopStyle','borderRightStyle','borderBottomStyle','borderLeftStyle'],
_borderWidthNames : ['borderTopWidth','borderRightWidth','borderBottomWidth','borderLeftWidth'],
_paddingWidthNames : ['paddingTop','paddingRight','paddingBottom','paddingLeft'],
getCurrentStyle : function(element,attribute,defaultValue){
var currentValue=null
if(element){
if(element.currentStyle){
currentValue=element.currentStyle[attribute]
}else if(document.defaultView&&document.defaultView.getComputedStyle){
var style=document.defaultView.getComputedStyle(element,null)
if(style){
currentValue=style[attribute]}}
if(!currentValue&&element.style.getPropertyValue){
currentValue=element.style.getPropertyValue(attribute)}
else if(!currentValue&&element.style.getAttribute){
currentValue=element.style.getAttribute(attribute)}}
if((!currentValue || currentValue=="" || typeof(currentValue)==='undefined')){
if(typeof(defaultValue)!='undefined'){
currentValue=defaultValue}
else{
currentValue=null}}
return currentValue
},
getInheritedBackgroundColor : function(element){
if(!element)return '#FFFFFF'
var background=this.getCurrentStyle(element,'backgroundColor')
try{
while(!background || background=='' || background=='transparent' || background=='rgba(0, 0, 0, 0)'){
element=element.parentNode
if(!element){
background='#FFFFFF'
}else{
background=this.getCurrentStyle(element,'backgroundColor')}}
}catch(ex){
background='#FFFFFF'}
return background
},
getLocation : function(element){
if(element===document.documentElement){
return new Sys.UI.Point(0,0)}
if(Sys.Browser.agent==Sys.Browser.InternetExplorer&&Sys.Browser.version<7){
if(element.window===element || element.nodeType===9 || !element.getClientRects || !element.getBoundingClientRect)return new Sys.UI.Point(0,0)
var screenRects=element.getClientRects()
if(!screenRects || !screenRects.length){
return new Sys.UI.Point(0,0)}
var first=screenRects[0]
var dLeft=0
var dTop=0
if(element.ownerDocument.parentWindow.frameElement){
var clientRect=element.getBoundingClientRect()
if(!clientRect){
return new Sys.UI.Point(0,0)}
var minLeft=first.left
var minTop=first.top
for(var i=1;i<screenRects.length;i++){
var r=screenRects[i]
if(r.left<minLeft){
minLeft=r.left}
if(r.top<minTop){
minTop=r.top}}
dLeft=minLeft-clientRect.left
dTop=minTop-clientRect.top}
var ownerDocument=element.document.documentElement
return new Sys.UI.Point(first.left-2-dLeft+ownerDocument.scrollLeft,first.top-2-dTop+ownerDocument.scrollTop)}
return Sys.UI.DomElement.getLocation(element)
},
setLocation : function(element,point){
Sys.UI.DomElement.setLocation(element,point.x,point.y)
},
getContentSize : function(element){
if(!element){
throw Error.argumentNull('element')}
var size=this.getSize(element)
var borderBox=this.getBorderBox(element)
var paddingBox=this.getPaddingBox(element)
return{
width : size.width-borderBox.horizontal-paddingBox.horizontal,
height : size.height-borderBox.vertical-paddingBox.vertical}
},
getSize : function(element){
if(!element){
throw Error.argumentNull('element')}
return{
width: element.offsetWidth,
height: element.offsetHeight}
},
setContentSize : function(element,size){
if(!element){
throw Error.argumentNull('element')}
if(!size){
throw Error.argumentNull('size')}
if(this.getCurrentStyle(element,'MozBoxSizing')=='border-box' || this.getCurrentStyle(element,'BoxSizing')=='border-box'){
var borderBox=this.getBorderBox(element)
var paddingBox=this.getPaddingBox(element)
size={
width: size.width+borderBox.horizontal+paddingBox.horizontal,
height: size.height+borderBox.vertical+paddingBox.vertical}}
element.style.width=size.width.toString()+'px'
element.style.height=size.height.toString()+'px'
},
setSize : function(element,size){
if(!element){
throw Error.argumentNull('element')}
if(!size){
throw Error.argumentNull('size')}
var borderBox=this.getBorderBox(element)
var paddingBox=this.getPaddingBox(element)
var contentSize={
width: size.width-borderBox.horizontal-paddingBox.horizontal,
height: size.height-borderBox.vertical-paddingBox.vertical}
this.setContentSize(element,contentSize)
},
getBounds : function(element){
var offset=CommonToolkitScripts.getLocation(element)
return new Sys.UI.Bounds(offset.x,offset.y,element.offsetWidth || 0,element.offsetHeight || 0)
},
setBounds : function(element,bounds){
if(!element){
throw Error.argumentNull('element')}
if(!bounds){
throw Error.argumentNull('bounds')}
this.setSize(element,bounds)
CommonToolkitScripts.setLocation(element,bounds)
},
getClientBounds : function(){
var clientWidth
var clientHeight
switch(Sys.Browser.agent){
case Sys.Browser.InternetExplorer:
clientWidth=document.documentElement.clientWidth
clientHeight=document.documentElement.clientHeight
break
case Sys.Browser.Safari:
clientWidth=window.innerWidth
clientHeight=window.innerHeight
break
case Sys.Browser.Opera:
clientWidth=Math.min(window.innerWidth,document.body.clientWidth)
clientHeight=Math.min(window.innerHeight,document.body.clientHeight)
break
default:
clientWidth=Math.min(window.innerWidth,document.documentElement.clientWidth)
clientHeight=Math.min(window.innerHeight,document.documentElement.clientHeight)
break}
return new Sys.UI.Bounds(0,0,clientWidth,clientHeight)
},
getBorderBox : function(element){
if(!element){
throw Error.argumentNull('element')}
var box={
top: this.getBorderWidth(element,AjaxControlToolkit.BoxSide.Top),
right: this.getBorderWidth(element,AjaxControlToolkit.BoxSide.Right),
bottom: this.getBorderWidth(element,AjaxControlToolkit.BoxSide.Bottom),
left: this.getBorderWidth(element,AjaxControlToolkit.BoxSide.Left)}
box.horizontal=box.left+box.right
box.vertical=box.top+box.bottom
return box
},
getPaddingBox : function(element){
if(!element){
throw Error.argumentNull('element')}
var box={
top: this.getPadding(element,AjaxControlToolkit.BoxSide.Top),
right: this.getPadding(element,AjaxControlToolkit.BoxSide.Right),
bottom: this.getPadding(element,AjaxControlToolkit.BoxSide.Bottom),
left: this.getPadding(element,AjaxControlToolkit.BoxSide.Left)}
box.horizontal=box.left+box.right
box.vertical=box.top+box.bottom
return box
},
isBorderVisible : function(element,boxSide){
if(!element){
throw Error.argumentNull('element')}
if(boxSide<AjaxControlToolkit.BoxSide.Top || boxSide>AjaxControlToolkit.BoxSide.Left){
throw Error.argumentOutOfRange("Argument 'boxSide' out of the range of expected values")}
var styleName=this._borderStyleNames[boxSide]
var styleValue=this.getCurrentStyle(element,styleName)
return styleValue !="none"
},
getBorderWidth : function(element,boxSide){
if(!element){
throw Error.argumentNull('element')}
if(boxSide<AjaxControlToolkit.BoxSide.Top || boxSide>AjaxControlToolkit.BoxSide.Left){
throw Error.argumentOutOfRange("Argument 'boxSide' out of the range of expected values")}
if(!this.isBorderVisible(element,boxSide)){
return 0}
var styleName=this._borderWidthNames[boxSide]
var styleValue=this.getCurrentStyle(element,styleName)
return this.parseBorderWidth(styleValue)
},
getPadding : function(element,boxSide){
if(!element){
throw Error.argumentNull('element')}
if(boxSide<AjaxControlToolkit.BoxSide.Top || boxSide>AjaxControlToolkit.BoxSide.Left){
throw Error.argumentOutOfRange("Argument 'boxSide' out of the range of expected values")}
var styleName=this._paddingWidthNames[boxSide]
var styleValue=this.getCurrentStyle(element,styleName)
return this.parsePadding(styleValue)
},
parseBorderWidth : function(borderWidth){
if(borderWidth){
switch(borderWidth){
case 'thin':
case 'medium':
case 'thick':
return this._borderThicknesses[borderWidth]
case 'inherit':
return 0}
var unit=this.parseUnit(borderWidth)
Sys.Debug.assert(unit.type=='px','A unit type of '+unit.type+' is invalid for parseBorderWidth')
return unit.size}
return 0
},
parsePadding : function(padding){
if(padding){
if(padding=='inherit'){
return 0}
var unit=this.parseUnit(padding)
Sys.Debug.assert(unit.type=='px','A unit type of '+unit.type+' is invalid for parsePadding')
return unit.size}
return 0
},
parseUnit : function(value){
if(!value){
throw Error.argumentNull('value')}
value=value.trim().toLowerCase()
var l=value.length
var s=-1
for(var i=0;i<l;i++){
var ch=value.substr(i,1)
if((ch<'0' || ch>'9')&&ch !='-'&&ch !='.'&&ch !=','){
break}
s=i}
if(s==-1){
throw Error.create("No digits.")}
var type
var size
if(s<(l-1)){
type=value.substring(s+1).trim()
}else{
type='px'}
size=parseFloat(value.substr(0,s+1))
if(type=='px'){
size=Math.floor(size)}
return{
size: size,
type: type}
},
getElementOpacity : function(element){
if(!element){
throw Error.argumentNull('element')}
var hasOpacity=false
var opacity
if(element.filters){
var filters=element.filters
if(filters.length !==0){
var alphaFilter=filters['DXImageTransform.Microsoft.Alpha']
if(alphaFilter){
opacity=alphaFilter.opacity/100.0
hasOpacity=true}}}
else{
opacity=this.getCurrentStyle(element,'opacity',1)
hasOpacity=true}
if(hasOpacity===false){
return 1.0}
return parseFloat(opacity)
},
setElementOpacity : function(element,value){
if(!element){
throw Error.argumentNull('element')}
if(element.filters){
var filters=element.filters
var createFilter=true
if(filters.length !==0){
var alphaFilter=filters['DXImageTransform.Microsoft.Alpha']
if(alphaFilter){
createFilter=false
alphaFilter.opacity=value*100}}
if(createFilter){
element.style.filter='progid:DXImageTransform.Microsoft.Alpha(opacity='+(value*100)+')'}}
else{
element.style.opacity=value}
},
resolveFunction : function(value){
if(value){
if(value instanceof Function){
return value
}else if(String.isInstanceOfType(value)&&value.length>0){
var func
if((func=window[value])instanceof Function){
return func
}else if((func=eval(value))instanceof Function){
return func}}}
return null
},
addCssClasses : function(element,classNames){
for(var i=0;i<classNames.length;i++){
Sys.UI.DomElement.addCssClass(element,classNames[i])}
},
removeCssClasses : function(element,classNames){
for(var i=0;i<classNames.length;i++){
Sys.UI.DomElement.removeCssClass(element,classNames[i])}
},
setStyle : function(element,style){
$common.applyProperties(element.style,style)
},
removeHandlers : function(element,events){
for(var name in events){
$removeHandler(element,name,events[name])}
},
containsPoint : function(rect,x,y){
return x>=rect.x&&x<=(rect.x+rect.width)&&y>=rect.y&&y<=(rect.y+rect.width)
},
isKeyDigit : function(keyCode){
return(0x30<=keyCode&&keyCode<=0x39)
},
isKeyNavigation : function(keyCode){
return(Sys.UI.Key.left<=keyCode&&keyCode<=Sys.UI.Key.down)
},
padLeft : function(text,size,ch,truncate){
return AjaxControlToolkit.CommonToolkitScripts._pad(text,size || 2,ch || ' ','l',truncate || false)
},
padRight : function(text,size,ch,truncate){
return AjaxControlToolkit.CommonToolkitScripts._pad(text,size || 2,ch || ' ','r',truncate || false)
},
_pad : function(text,size,ch,side,truncate){
text=text.toString()
var length=text.length
var builder=new Sys.StringBuilder()
if(side=='r'){
builder.append(text)}
while(length<size){
builder.append(ch)
length++}
if(side=='l'){
builder.append(text)}
var result=builder.toString()
if(truncate&&result.length>size){
if(side=='l'){
result=result.substr(result.length-size,size)
}else{
result=result.substr(0,size)}}
return result
},
applyProperties : function(target,properties){
for(var p in properties){
var pv=properties[p]
if(Object.getType(pv)===Object){
var tv=target[p]
AjaxControlToolkit.CommonToolkitScripts.applyProperties(tv,pv)
}else{
target[p]=pv}}
},
createElementFromTemplate : function(template,appendToParent){
var elt=document.createElement(template.nodeName)
if(typeof(template.properties)!=='undefined')AjaxControlToolkit.CommonToolkitScripts.applyProperties(elt,template.properties)
if(typeof(template.cssClasses)!=='undefined')AjaxControlToolkit.CommonToolkitScripts.addCssClasses(elt,template.cssClasses)
if(typeof(template.events)!=='undefined')$addHandlers(elt,template.events)
if(typeof(template.visible)!=='undefined')Sys.UI.DomElement.setVisible(elt,template.visible)
if(appendToParent)appendToParent.appendChild(elt)
if(typeof(template.opacity)!=='undefined')AjaxControlToolkit.CommonToolkitScripts.setElementOpacity(elt,template.opacity)
return elt}}
var CommonToolkitScripts=AjaxControlToolkit.CommonToolkitScripts=new AjaxControlToolkit._CommonToolkitScripts()
var $common=CommonToolkitScripts
AjaxControlToolkit._DomUtility=function(){}
AjaxControlToolkit._DomUtility.prototype={
isDescendant : function(ancestor,descendant){
for(var n=descendant.parentNode;n !=null;n=n.parentNode){
if(n==ancestor)return true}
return false
},
isDescendantOrSelf : function(ancestor,descendant){
if(ancestor===descendant)
return true
return AjaxControlToolkit.DomUtility.isDescendant(ancestor,descendant)
},
isAncestor : function(descendant,ancestor){
return AjaxControlToolkit.DomUtility.isDescendant(ancestor,descendant)
},
isAncestorOrSelf : function(descendant,ancestor){
if(descendant===ancestor)
return true
return AjaxControlToolkit.DomUtility.isDescendant(ancestor,descendant)
},
isSibling : function(self,sibling){
var parent=self.parentNode
for(var i=0;i<parent.childNodes.length;i++){
if(parent.childNodes[i]==sibling)return true}
return false}}
AjaxControlToolkit._DomUtility.registerClass("AjaxControlToolkit._DomUtility")
AjaxControlToolkit.DomUtility=new AjaxControlToolkit._DomUtility()
if(Sys.CultureInfo.prototype._getAbbrMonthIndex){
try{
Sys.CultureInfo.prototype._getAbbrMonthIndex('')
}catch(ex){
Sys.CultureInfo.prototype._getAbbrMonthIndex=function(value){
if(!this._upperAbbrMonths){
this._upperAbbrMonths=this._toUpperArray(this.dateTimeFormat.AbbreviatedMonthNames)}
return Array.indexOf(this._upperAbbrMonths,this._toUpper(value))}
Sys.CultureInfo.CurrentCulture._getAbbrMonthIndex=Sys.CultureInfo.prototype._getAbbrMonthIndex
Sys.CultureInfo.InvariantCulture._getAbbrMonthIndex=Sys.CultureInfo.prototype._getAbbrMonthIndex}}
