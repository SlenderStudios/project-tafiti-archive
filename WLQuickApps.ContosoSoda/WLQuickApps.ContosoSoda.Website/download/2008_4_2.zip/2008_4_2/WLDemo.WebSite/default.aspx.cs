﻿using System;
using System.Collections;
using System.Configuration;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Xml.Linq;
using UserManagement;
using VideoManagement;
using System.Xml;

public partial class sl_home : System.Web.UI.Page
{
    static User userHandler = new User();
    static Video videoHandler = new Video();
    protected string teamlist = null;
    protected string[] video_info = new string[6];
    protected string[] user_info = new string[5];
    protected void Page_Load(object sender, EventArgs e)
    {
        
        int total_user, count = 0;
        DataView dvUsers = new DataView();
        dvUsers = userHandler.GetUserList3();
        dvUsers.Sort = "ID desc";
        total_user = dvUsers.Count;
        if (total_user > 4)
        {
            total_user = 4;
        }

        for (count = 0; count < total_user; count++)
        {
	        teamlist +="<tr>";
			    teamlist +="<td class=\"team_table_c1\">"+dvUsers[count]["Subject"].ToString()+"</td>";
				teamlist +="<td class=\"team_table_c2\">"+dvUsers[count]["Name"].ToString()+"</td>";
                teamlist += "<td class=\"team_table_c3\"><a href=\"javascript:void(0);\" onclick=\"window.open('chat.aspx?invitee=" + dvUsers[count]["ImId"].ToString() + "','_blank','height=500, location=0, menubar=0, resizable=0, scrollbars=0, status=0, titlebar=0, toolbar=0, width=700');\"><img src=\"http://messenger.services.live.com/users/" + dvUsers[count]["ImId"].ToString() + "/presenceimage?mkt=en-hk\" /></a></td>";
		    teamlist +="</tr>";
           
        }
        //Get video detail
        
        video_info = videoHandler.GetVideoTemp();
        user_info = userHandler.GetUsers(video_info[5]);
        string im_id = user_info[2];

    }
}
