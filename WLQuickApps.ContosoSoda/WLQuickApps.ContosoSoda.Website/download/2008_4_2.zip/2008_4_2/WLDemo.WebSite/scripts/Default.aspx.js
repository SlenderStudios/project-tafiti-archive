﻿function SendAlertMessage() {
    //send message
    AlertService.SendGroupRequest(currentCulture, onSendRequest, onFailed);
}


function onSendRequest(result)
{
    //Localize appointmentSentText in resource file, defined in Default.aspx
    popup.show(appointmentSentText);
}

function onFailed(error)
{      
    alert("Error:"+error.get_message());
}
